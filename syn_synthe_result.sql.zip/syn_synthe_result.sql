-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 07, 2017 at 08:19 PM
-- Server version: 5.5.51-38.2
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `syn_synthe_result`
--

-- --------------------------------------------------------

--
-- Table structure for table `ADVANCED_9`
--

CREATE TABLE IF NOT EXISTS `ADVANCED_9` (
  `id` int(11) NOT NULL,
  `exam_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `roll` int(10) DEFAULT NULL,
  `phy.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chem.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maths` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `%` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rank` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test` int(9) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ADVANCED_10`
--

CREATE TABLE IF NOT EXISTS `ADVANCED_10` (
  `id` int(11) NOT NULL,
  `exam_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `roll` int(10) DEFAULT NULL,
  `phy.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chem.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maths` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `%` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rank` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test` int(9) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ADVANCED_11`
--

CREATE TABLE IF NOT EXISTS `ADVANCED_11` (
  `id` int(11) NOT NULL,
  `exam_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `roll` int(10) DEFAULT NULL,
  `phy.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chem.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maths` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `%` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rank` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test` int(9) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `AIIMS_2`
--

CREATE TABLE IF NOT EXISTS `AIIMS_2` (
  `id` int(11) NOT NULL,
  `exam_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `roll` int(10) DEFAULT NULL,
  `phy.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chem.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bot.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zoo.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `g.k.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `%` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rank` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test` int(9) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `AIIMS_3`
--

CREATE TABLE IF NOT EXISTS `AIIMS_3` (
  `id` int(11) NOT NULL,
  `exam_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `roll` int(10) DEFAULT NULL,
  `phy.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chem.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bot.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zoo.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `g.k.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `%` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rank` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test` int(9) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `AIIMS_4`
--

CREATE TABLE IF NOT EXISTS `AIIMS_4` (
  `id` int(11) NOT NULL,
  `exam_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `roll` int(10) DEFAULT NULL,
  `phy.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chem.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bot.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zoo.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `g.k.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `%` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rank` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test` int(9) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ap`
--

CREATE TABLE IF NOT EXISTS `ap` (
  `id` int(11) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `roll` int(11) DEFAULT NULL,
  `s1` enum('p','a','h') DEFAULT NULL,
  `s2` enum('p','a','h') DEFAULT NULL,
  `s3` enum('p','a','h') DEFAULT NULL,
  `s4` enum('p','a','h') DEFAULT NULL,
  `s5` enum('p','a','h') DEFAULT NULL,
  `s6` enum('p','a','h') DEFAULT NULL,
  `s7` enum('p','a','h') DEFAULT NULL,
  `s8` enum('p','a','h') DEFAULT NULL,
  `s9` enum('p','a','h') DEFAULT NULL,
  `s10` enum('p','a','h') DEFAULT NULL,
  `s11` enum('p','a','h') DEFAULT NULL,
  `s12` enum('p','a','h') DEFAULT NULL,
  `s13` enum('p','a','h') DEFAULT NULL,
  `s14` enum('p','a','h') DEFAULT NULL,
  `s15` enum('p','a','h') DEFAULT NULL,
  `s16` enum('p','a','h') DEFAULT NULL,
  `s17` enum('p','a','h') DEFAULT NULL,
  `s18` enum('p','a','h') DEFAULT NULL,
  `s19` enum('p','a','h') DEFAULT NULL,
  `s20` enum('p','a','h') DEFAULT NULL,
  `s21` enum('p','a','h') DEFAULT NULL,
  `s22` enum('p','a','h') DEFAULT NULL,
  `s23` enum('p','a','h') DEFAULT NULL,
  `s24` enum('p','a','h') DEFAULT NULL,
  `s25` enum('p','a','h') DEFAULT NULL,
  `s26` enum('p','a','h') DEFAULT NULL,
  `s27` enum('p','a','h') DEFAULT NULL,
  `s28` enum('p','a','h') DEFAULT NULL,
  `s29` enum('p','a','h') DEFAULT NULL,
  `s30` enum('p','a','h') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `aug`
--

CREATE TABLE IF NOT EXISTS `aug` (
  `id` int(11) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `roll` int(11) DEFAULT NULL,
  `s1` enum('p','a','h') DEFAULT NULL,
  `s2` enum('p','a','h') DEFAULT NULL,
  `s3` enum('p','a','h') DEFAULT NULL,
  `s4` enum('p','a','h') DEFAULT NULL,
  `s5` enum('p','a','h') DEFAULT NULL,
  `s6` enum('p','a','h') DEFAULT NULL,
  `s7` enum('p','a','h') DEFAULT NULL,
  `s8` enum('p','a','h') DEFAULT NULL,
  `s9` enum('p','a','h') DEFAULT NULL,
  `s10` enum('p','a','h') DEFAULT NULL,
  `s11` enum('p','a','h') DEFAULT NULL,
  `s12` enum('p','a','h') DEFAULT NULL,
  `s13` enum('p','a','h') DEFAULT NULL,
  `s14` enum('p','a','h') DEFAULT NULL,
  `s15` enum('p','a','h') DEFAULT NULL,
  `s16` enum('p','a','h') DEFAULT NULL,
  `s17` enum('p','a','h') DEFAULT NULL,
  `s18` enum('p','a','h') DEFAULT NULL,
  `s19` enum('p','a','h') DEFAULT NULL,
  `s20` enum('p','a','h') DEFAULT NULL,
  `s21` enum('p','a','h') DEFAULT NULL,
  `s22` enum('p','a','h') DEFAULT NULL,
  `s23` enum('p','a','h') DEFAULT NULL,
  `s24` enum('p','a','h') DEFAULT NULL,
  `s25` enum('p','a','h') DEFAULT NULL,
  `s26` enum('p','a','h') DEFAULT NULL,
  `s27` enum('p','a','h') DEFAULT NULL,
  `s28` enum('p','a','h') DEFAULT NULL,
  `s29` enum('p','a','h') DEFAULT NULL,
  `s30` enum('p','a','h') DEFAULT NULL,
  `s31` enum('p','a','h') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `batch`
--

CREATE TABLE IF NOT EXISTS `batch` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `class_id` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `batch`
--

INSERT INTO `batch` (`id`, `name`, `class_id`) VALUES
(1, 'D-1', 2),
(2, 'D-2', 2),
(3, 'D-3', 2),
(4, 'D-4', 2),
(5, 'D-5', 2),
(6, 'D-6', 2),
(7, 'E-1', 3),
(8, 'E-2', 3),
(9, 'E-3', 3),
(10, 'H-1', 3),
(11, 'H-2', 3),
(12, 'E-1', 4),
(13, 'E-2', 4),
(14, 'E-3', 4),
(15, 'E-4', 4),
(16, 'E-5', 4),
(17, 'H-1', 4),
(18, 'H-2', 4),
(19, 'H-3', 4),
(20, '10th', 5),
(21, '9th', 6),
(22, '8th', 7),
(23, 'IIT Target', 9),
(24, 'E.M.', 10),
(25, 'H.M.', 10),
(26, 'E.M.', 11),
(27, 'H.M.', 11),
(28, 'TS 2017 (Bio)', 12),
(29, 'TS 2017 (Maths)', 13);

-- --------------------------------------------------------

--
-- Table structure for table `BOARD_3`
--

CREATE TABLE IF NOT EXISTS `BOARD_3` (
  `id` int(11) NOT NULL,
  `exam_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `roll` int(10) DEFAULT NULL,
  `phy.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chem.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bio.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `%` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rank` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test` int(9) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `BOARD_4`
--

CREATE TABLE IF NOT EXISTS `BOARD_4` (
  `id` int(11) NOT NULL,
  `exam_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `roll` int(10) DEFAULT NULL,
  `phy.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chem.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bio.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `%` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rank` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test` int(9) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `BOARD_10`
--

CREATE TABLE IF NOT EXISTS `BOARD_10` (
  `id` int(11) NOT NULL,
  `exam_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `roll` int(10) DEFAULT NULL,
  `phy.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chem.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maths` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `%` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rank` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test` int(9) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `BOARD_11`
--

CREATE TABLE IF NOT EXISTS `BOARD_11` (
  `id` int(11) NOT NULL,
  `exam_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `roll` int(10) DEFAULT NULL,
  `phy.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chem` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maths` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `%` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rank` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test` int(9) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE IF NOT EXISTS `class` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `fee` int(11) NOT NULL,
  `tax` int(11) NOT NULL,
  `total_fees` varchar(10) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`id`, `name`, `fee`, `tax`, `total_fees`) VALUES
(1, 'Crash Course (Bio)', 15000, 15, '17250'),
(2, 'Target Bio', 70000, 18, '82600'),
(3, '12th Bio', 55000, 18, '64900'),
(4, '11th Bio', 55000, 18, '64900'),
(5, '10th', 28000, 18, '33040'),
(6, '9th', 26000, 18, '30680'),
(7, '8th', 22000, 18, '25960'),
(8, 'Crash Course (Maths)', 15000, 15, '17250'),
(9, 'Target Maths', 80000, 18, '94400'),
(10, '12th Maths', 65000, 18, '76700'),
(11, '11th Maths', 65000, 18, '76700'),
(12, 'Test Series 2017 (Bio)', 8000, 18, '9440'),
(13, 'Test Series 2017 (Maths)', 8000, 18, '9440');

-- --------------------------------------------------------

--
-- Table structure for table `coloumn`
--

CREATE TABLE IF NOT EXISTS `coloumn` (
  `id` int(11) NOT NULL,
  `patt_id` int(11) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `sequence` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coloumn`
--

INSERT INTO `coloumn` (`id`, `patt_id`, `name`, `sequence`) VALUES
(1, 2, 'phy.', 1),
(2, 2, 'chem.', 2),
(3, 2, 'bot.', 3),
(4, 2, 'zoo.', 4),
(5, 2, 'total', 5),
(6, 2, '%', 6),
(7, 2, 'rank', 7),
(8, 3, 'phy.', 1),
(9, 3, 'chem.', 2),
(10, 3, 'bot.', 3),
(11, 3, 'zoo.', 4),
(12, 3, 'g.k.', 5),
(13, 3, 'total', 6),
(14, 3, '%', 7),
(15, 3, 'rank', 8),
(16, 4, 'phy.', 1),
(17, 4, 'chem.', 2),
(18, 4, 'bot.', 3),
(19, 4, 'zoo.', 4),
(20, 4, 'total', 5),
(21, 4, '%', 6),
(22, 4, 'rank', 7),
(23, 5, 'phy.', 1),
(24, 5, 'chem.', 2),
(25, 5, 'bot.', 3),
(26, 5, 'zoo.', 4),
(27, 5, 'g.k.', 5),
(28, 5, 'total', 6),
(29, 5, '%', 7),
(30, 5, 'rank', 8),
(31, 6, 'phy.', 1),
(32, 6, 'chem.', 2),
(33, 6, 'bio.', 3),
(34, 6, 'total', 4),
(35, 6, '%', 5),
(36, 6, 'rank', 6),
(37, 7, 'phy.', 1),
(38, 7, 'chem.', 2),
(39, 7, 'bot.', 3),
(40, 7, 'zoo.', 4),
(41, 7, 'total', 5),
(42, 7, '%', 6),
(43, 7, 'rank', 7),
(44, 8, 'phy.', 1),
(45, 8, 'chem.', 2),
(46, 8, 'bio.', 3),
(47, 8, 'total', 4),
(48, 8, '%', 5),
(49, 8, 'rank', 6),
(50, 9, 'phy.', 1),
(51, 9, 'chem.', 2),
(52, 9, 'bot.', 3),
(53, 9, 'zoo.', 4),
(54, 9, 'g.k.', 5),
(55, 9, 'total', 6),
(56, 9, '%', 7),
(57, 9, 'rank', 8),
(58, 10, 'phy.', 1),
(59, 10, 'chem.', 2),
(60, 10, 'maths', 3),
(61, 10, 'total', 4),
(62, 10, '%', 5),
(63, 10, 'rank', 6),
(64, 11, 'phy.', 1),
(65, 11, 'chem.', 2),
(66, 11, 'maths', 3),
(67, 11, 'total', 4),
(68, 11, '%', 5),
(69, 11, 'rank', 6),
(70, 12, 'phy.', 1),
(71, 12, 'chem.', 2),
(72, 12, 'maths', 3),
(73, 12, 'total', 4),
(74, 12, '%', 5),
(75, 12, 'rank', 6),
(76, 13, 'phy.', 1),
(77, 13, 'chem.', 2),
(78, 13, 'maths', 3),
(79, 13, 'total', 4),
(80, 13, '%', 5),
(81, 13, 'rank', 6),
(82, 14, 'phy.', 1),
(83, 14, 'chem.', 2),
(84, 14, 'maths', 3),
(85, 14, 'total', 4),
(86, 14, '%', 5),
(87, 14, 'rank', 6),
(88, 15, 'phy.', 1),
(89, 15, 'chem.', 2),
(90, 15, 'maths', 3),
(91, 15, 'total', 4),
(92, 15, '%', 5),
(93, 15, 'rank', 6),
(94, 16, 'phy.', 1),
(95, 16, 'chem', 2),
(96, 16, 'maths', 3),
(97, 16, 'total', 4),
(98, 16, '%', 5),
(99, 16, 'rank', 6),
(100, 17, 'phy.', 1),
(101, 17, 'chem.', 2),
(102, 17, 'maths', 3),
(103, 17, 'total', 4),
(104, 17, '%', 5),
(105, 17, 'rank', 6);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `contact_subject` varchar(200) NOT NULL,
  `contact_query` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `decm`
--

CREATE TABLE IF NOT EXISTS `decm` (
  `id` int(11) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `roll` int(11) DEFAULT NULL,
  `s1` enum('p','a','h') DEFAULT NULL,
  `s2` enum('p','a','h') DEFAULT NULL,
  `s3` enum('p','a','h') DEFAULT NULL,
  `s4` enum('p','a','h') DEFAULT NULL,
  `s5` enum('p','a','h') DEFAULT NULL,
  `s6` enum('p','a','h') DEFAULT NULL,
  `s7` enum('p','a','h') DEFAULT NULL,
  `s8` enum('p','a','h') DEFAULT NULL,
  `s9` enum('p','a','h') DEFAULT NULL,
  `s10` enum('p','a','h') DEFAULT NULL,
  `s11` enum('p','a','h') DEFAULT NULL,
  `s12` enum('p','a','h') DEFAULT NULL,
  `s13` enum('p','a','h') DEFAULT NULL,
  `s14` enum('p','a','h') DEFAULT NULL,
  `s15` enum('p','a','h') DEFAULT NULL,
  `s16` enum('p','a','h') DEFAULT NULL,
  `s17` enum('p','a','h') DEFAULT NULL,
  `s18` enum('p','a','h') DEFAULT NULL,
  `s19` enum('p','a','h') DEFAULT NULL,
  `s20` enum('p','a','h') DEFAULT NULL,
  `s21` enum('p','a','h') DEFAULT NULL,
  `s22` enum('p','a','h') DEFAULT NULL,
  `s23` enum('p','a','h') DEFAULT NULL,
  `s24` enum('p','a','h') DEFAULT NULL,
  `s25` enum('p','a','h') DEFAULT NULL,
  `s26` enum('p','a','h') DEFAULT NULL,
  `s27` enum('p','a','h') DEFAULT NULL,
  `s28` enum('p','a','h') DEFAULT NULL,
  `s29` enum('p','a','h') DEFAULT NULL,
  `s30` enum('p','a','h') DEFAULT NULL,
  `s31` enum('p','a','h') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `feb`
--

CREATE TABLE IF NOT EXISTS `feb` (
  `id` int(11) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `roll` int(11) DEFAULT NULL,
  `s1` enum('p','a','h') DEFAULT NULL,
  `s2` enum('p','a','h') DEFAULT NULL,
  `s3` enum('p','a','h') DEFAULT NULL,
  `s4` enum('p','a','h') DEFAULT NULL,
  `s5` enum('p','a','h') DEFAULT NULL,
  `s6` enum('p','a','h') DEFAULT NULL,
  `s7` enum('p','a','h') DEFAULT NULL,
  `s8` enum('p','a','h') DEFAULT NULL,
  `s9` enum('p','a','h') DEFAULT NULL,
  `s10` enum('p','a','h') DEFAULT NULL,
  `s11` enum('p','a','h') DEFAULT NULL,
  `s12` enum('p','a','h') DEFAULT NULL,
  `s13` enum('p','a','h') DEFAULT NULL,
  `s14` enum('p','a','h') DEFAULT NULL,
  `s15` enum('p','a','h') DEFAULT NULL,
  `s16` enum('p','a','h') DEFAULT NULL,
  `s17` enum('p','a','h') DEFAULT NULL,
  `s18` enum('p','a','h') DEFAULT NULL,
  `s19` enum('p','a','h') DEFAULT NULL,
  `s20` enum('p','a','h') DEFAULT NULL,
  `s21` enum('p','a','h') DEFAULT NULL,
  `s22` enum('p','a','h') DEFAULT NULL,
  `s23` enum('p','a','h') DEFAULT NULL,
  `s24` enum('p','a','h') DEFAULT NULL,
  `s25` enum('p','a','h') DEFAULT NULL,
  `s26` enum('p','a','h') DEFAULT NULL,
  `s27` enum('p','a','h') DEFAULT NULL,
  `s28` enum('p','a','h') DEFAULT NULL,
  `s29` enum('p','a','h') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `feesexcel`
--

CREATE TABLE IF NOT EXISTS `feesexcel` (
  `id` int(11) NOT NULL,
  `filename` text NOT NULL,
  `datee` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fees_submit`
--

CREATE TABLE IF NOT EXISTS `fees_submit` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `fee_submit` int(11) NOT NULL,
  `paid_by` enum('cash','cheque','dd') NOT NULL DEFAULT 'cash',
  `datee` varchar(20) NOT NULL,
  `pay_number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `general_setting`
--

CREATE TABLE IF NOT EXISTS `general_setting` (
  `site_title` text NOT NULL,
  `site_url` text NOT NULL,
  `site_email` text NOT NULL,
  `meta_keywrd` text NOT NULL,
  `meta_desc` text NOT NULL,
  `admin_footer` text NOT NULL,
  `logo` text NOT NULL,
  `fb_link` text NOT NULL,
  `tw_link` text NOT NULL,
  `gmail_link` text NOT NULL,
  `yt_link` text NOT NULL,
  `lnkdn_link` text NOT NULL,
  `gtalk_link` text NOT NULL,
  `skype_link` text NOT NULL,
  `id` int(11) NOT NULL,
  `banner` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `general_setting`
--

INSERT INTO `general_setting` (`site_title`, `site_url`, `site_email`, `meta_keywrd`, `meta_desc`, `admin_footer`, `logo`, `fb_link`, `tw_link`, `gmail_link`, `yt_link`, `lnkdn_link`, `gtalk_link`, `skype_link`, `id`, `banner`) VALUES
('SPR | Synthesis', 'www.synthesis.ac.in/synthesis_result', 'synthesis_result@synthesis.ac.in', 'Synthesis Result, SPR, Medical Institute, IIT-JEE Institute', 'Synthesis Result, SPR, Medical Institute, IIT-JEE Institute', 'raj verma', '1501570492_logo_synthesis.png', 'www.facebook.com/axixa', 'www.twitter.com/axixa', 'www.gmail.com/axixa', 'www.gmail.com/axixa', 'www.linkedin.com/axixa', 'www.googletalk.com/axixa', 'www.skype.com/axixa', 1, '1501571480_banner.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `jan`
--

CREATE TABLE IF NOT EXISTS `jan` (
  `id` int(11) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `roll` int(11) DEFAULT NULL,
  `s1` enum('p','a','h') DEFAULT NULL,
  `s2` enum('p','a','h') DEFAULT NULL,
  `s3` enum('p','a','h') DEFAULT NULL,
  `s4` enum('p','a','h') DEFAULT NULL,
  `s5` enum('p','a','h') DEFAULT NULL,
  `s6` enum('p','a','h') DEFAULT NULL,
  `s7` enum('p','a','h') DEFAULT NULL,
  `s8` enum('p','a','h') DEFAULT NULL,
  `s9` enum('p','a','h') DEFAULT NULL,
  `s10` enum('p','a','h') DEFAULT NULL,
  `s11` enum('p','a','h') DEFAULT NULL,
  `s12` enum('p','a','h') DEFAULT NULL,
  `s13` enum('p','a','h') DEFAULT NULL,
  `s14` enum('p','a','h') DEFAULT NULL,
  `s15` enum('p','a','h') DEFAULT NULL,
  `s16` enum('p','a','h') DEFAULT NULL,
  `s17` enum('p','a','h') DEFAULT NULL,
  `s18` enum('p','a','h') DEFAULT NULL,
  `s19` enum('p','a','h') DEFAULT NULL,
  `s20` enum('p','a','h') DEFAULT NULL,
  `s21` enum('p','a','h') DEFAULT NULL,
  `s22` enum('p','a','h') DEFAULT NULL,
  `s23` enum('p','a','h') DEFAULT NULL,
  `s24` enum('p','a','h') DEFAULT NULL,
  `s25` enum('p','a','h') DEFAULT NULL,
  `s26` enum('p','a','h') DEFAULT NULL,
  `s27` enum('p','a','h') DEFAULT NULL,
  `s28` enum('p','a','h') DEFAULT NULL,
  `s29` enum('p','a','h') DEFAULT NULL,
  `s30` enum('p','a','h') DEFAULT NULL,
  `s31` enum('p','a','h') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `july`
--

CREATE TABLE IF NOT EXISTS `july` (
  `id` int(11) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `roll` int(11) DEFAULT NULL,
  `s1` enum('p','a','h') DEFAULT NULL,
  `s2` enum('p','a','h') DEFAULT NULL,
  `s3` enum('p','a','h') DEFAULT NULL,
  `s4` enum('p','a','h') DEFAULT NULL,
  `s5` enum('p','a','h') DEFAULT NULL,
  `s6` enum('p','a','h') DEFAULT NULL,
  `s7` enum('p','a','h') DEFAULT NULL,
  `s8` enum('p','a','h') DEFAULT NULL,
  `s9` enum('p','a','h') DEFAULT NULL,
  `s10` enum('p','a','h') DEFAULT NULL,
  `s11` enum('p','a','h') DEFAULT NULL,
  `s12` enum('p','a','h') DEFAULT NULL,
  `s13` enum('p','a','h') DEFAULT NULL,
  `s14` enum('p','a','h') DEFAULT NULL,
  `s15` enum('p','a','h') DEFAULT NULL,
  `s16` enum('p','a','h') DEFAULT NULL,
  `s17` enum('p','a','h') DEFAULT NULL,
  `s18` enum('p','a','h') DEFAULT NULL,
  `s19` enum('p','a','h') DEFAULT NULL,
  `s20` enum('p','a','h') DEFAULT NULL,
  `s21` enum('p','a','h') DEFAULT NULL,
  `s22` enum('p','a','h') DEFAULT NULL,
  `s23` enum('p','a','h') DEFAULT NULL,
  `s24` enum('p','a','h') DEFAULT NULL,
  `s25` enum('p','a','h') DEFAULT NULL,
  `s26` enum('p','a','h') DEFAULT NULL,
  `s27` enum('p','a','h') DEFAULT NULL,
  `s28` enum('p','a','h') DEFAULT NULL,
  `s29` enum('p','a','h') DEFAULT NULL,
  `s30` enum('p','a','h') DEFAULT NULL,
  `s31` enum('p','a','h') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `june`
--

CREATE TABLE IF NOT EXISTS `june` (
  `id` int(11) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `roll` int(11) DEFAULT NULL,
  `s1` enum('p','a','h') DEFAULT NULL,
  `s2` enum('p','a','h') DEFAULT NULL,
  `s3` enum('p','a','h') DEFAULT NULL,
  `s4` enum('p','a','h') DEFAULT NULL,
  `s5` enum('p','a','h') DEFAULT NULL,
  `s6` enum('p','a','h') DEFAULT NULL,
  `s7` enum('p','a','h') DEFAULT NULL,
  `s8` enum('p','a','h') DEFAULT NULL,
  `s9` enum('p','a','h') DEFAULT NULL,
  `s10` enum('p','a','h') DEFAULT NULL,
  `s11` enum('p','a','h') DEFAULT NULL,
  `s12` enum('p','a','h') DEFAULT NULL,
  `s13` enum('p','a','h') DEFAULT NULL,
  `s14` enum('p','a','h') DEFAULT NULL,
  `s15` enum('p','a','h') DEFAULT NULL,
  `s16` enum('p','a','h') DEFAULT NULL,
  `s17` enum('p','a','h') DEFAULT NULL,
  `s18` enum('p','a','h') DEFAULT NULL,
  `s19` enum('p','a','h') DEFAULT NULL,
  `s20` enum('p','a','h') DEFAULT NULL,
  `s21` enum('p','a','h') DEFAULT NULL,
  `s22` enum('p','a','h') DEFAULT NULL,
  `s23` enum('p','a','h') DEFAULT NULL,
  `s24` enum('p','a','h') DEFAULT NULL,
  `s25` enum('p','a','h') DEFAULT NULL,
  `s26` enum('p','a','h') DEFAULT NULL,
  `s27` enum('p','a','h') DEFAULT NULL,
  `s28` enum('p','a','h') DEFAULT NULL,
  `s29` enum('p','a','h') DEFAULT NULL,
  `s30` enum('p','a','h') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login_admin`
--

CREATE TABLE IF NOT EXISTS `login_admin` (
  `id` int(2) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `pswd` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_admin`
--

INSERT INTO `login_admin` (`id`, `uname`, `pswd`) VALUES
(1, '8947', 'c62ac98937679cd7fa090c411b5bba9c');

-- --------------------------------------------------------

--
-- Table structure for table `MAINS_9`
--

CREATE TABLE IF NOT EXISTS `MAINS_9` (
  `id` int(11) NOT NULL,
  `exam_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `roll` int(10) DEFAULT NULL,
  `phy.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chem.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maths` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `%` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rank` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test` int(9) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `MAINS_10`
--

CREATE TABLE IF NOT EXISTS `MAINS_10` (
  `id` int(11) NOT NULL,
  `exam_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `roll` int(10) DEFAULT NULL,
  `phy.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chem.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maths` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `%` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rank` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test` int(9) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `MAINS_11`
--

CREATE TABLE IF NOT EXISTS `MAINS_11` (
  `id` int(11) NOT NULL,
  `exam_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `roll` int(10) DEFAULT NULL,
  `phy.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chem.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maths` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `%` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rank` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test` int(9) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `march`
--

CREATE TABLE IF NOT EXISTS `march` (
  `id` int(11) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `roll` int(11) DEFAULT NULL,
  `s1` enum('p','a','h') DEFAULT NULL,
  `s2` enum('p','a','h') DEFAULT NULL,
  `s3` enum('p','a','h') DEFAULT NULL,
  `s4` enum('p','a','h') DEFAULT NULL,
  `s5` enum('p','a','h') DEFAULT NULL,
  `s6` enum('p','a','h') DEFAULT NULL,
  `s7` enum('p','a','h') DEFAULT NULL,
  `s8` enum('p','a','h') DEFAULT NULL,
  `s9` enum('p','a','h') DEFAULT NULL,
  `s10` enum('p','a','h') DEFAULT NULL,
  `s11` enum('p','a','h') DEFAULT NULL,
  `s12` enum('p','a','h') DEFAULT NULL,
  `s13` enum('p','a','h') DEFAULT NULL,
  `s14` enum('p','a','h') DEFAULT NULL,
  `s15` enum('p','a','h') DEFAULT NULL,
  `s16` enum('p','a','h') DEFAULT NULL,
  `s17` enum('p','a','h') DEFAULT NULL,
  `s18` enum('p','a','h') DEFAULT NULL,
  `s19` enum('p','a','h') DEFAULT NULL,
  `s20` enum('p','a','h') DEFAULT NULL,
  `s21` enum('p','a','h') DEFAULT NULL,
  `s22` enum('p','a','h') DEFAULT NULL,
  `s23` enum('p','a','h') DEFAULT NULL,
  `s24` enum('p','a','h') DEFAULT NULL,
  `s25` enum('p','a','h') DEFAULT NULL,
  `s26` enum('p','a','h') DEFAULT NULL,
  `s27` enum('p','a','h') DEFAULT NULL,
  `s28` enum('p','a','h') DEFAULT NULL,
  `s29` enum('p','a','h') DEFAULT NULL,
  `s30` enum('p','a','h') DEFAULT NULL,
  `s31` enum('p','a','h') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `may`
--

CREATE TABLE IF NOT EXISTS `may` (
  `id` int(11) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `roll` int(11) DEFAULT NULL,
  `s1` enum('p','a','h') DEFAULT NULL,
  `s2` enum('p','a','h') DEFAULT NULL,
  `s3` enum('p','a','h') DEFAULT NULL,
  `s4` enum('p','a','h') DEFAULT NULL,
  `s5` enum('p','a','h') DEFAULT NULL,
  `s6` enum('p','a','h') DEFAULT NULL,
  `s7` enum('p','a','h') DEFAULT NULL,
  `s8` enum('p','a','h') DEFAULT NULL,
  `s9` enum('p','a','h') DEFAULT NULL,
  `s10` enum('p','a','h') DEFAULT NULL,
  `s11` enum('p','a','h') DEFAULT NULL,
  `s12` enum('p','a','h') DEFAULT NULL,
  `s13` enum('p','a','h') DEFAULT NULL,
  `s14` enum('p','a','h') DEFAULT NULL,
  `s15` enum('p','a','h') DEFAULT NULL,
  `s16` enum('p','a','h') DEFAULT NULL,
  `s17` enum('p','a','h') DEFAULT NULL,
  `s18` enum('p','a','h') DEFAULT NULL,
  `s19` enum('p','a','h') DEFAULT NULL,
  `s20` enum('p','a','h') DEFAULT NULL,
  `s21` enum('p','a','h') DEFAULT NULL,
  `s22` enum('p','a','h') DEFAULT NULL,
  `s23` enum('p','a','h') DEFAULT NULL,
  `s24` enum('p','a','h') DEFAULT NULL,
  `s25` enum('p','a','h') DEFAULT NULL,
  `s26` enum('p','a','h') DEFAULT NULL,
  `s27` enum('p','a','h') DEFAULT NULL,
  `s28` enum('p','a','h') DEFAULT NULL,
  `s29` enum('p','a','h') DEFAULT NULL,
  `s30` enum('p','a','h') DEFAULT NULL,
  `s31` enum('p','a','h') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `menu_name`
--

CREATE TABLE IF NOT EXISTS `menu_name` (
  `home` varchar(6) NOT NULL,
  `spr` varchar(6) NOT NULL,
  `at_report` varchar(20) NOT NULL,
  `fee_detail` varchar(15) NOT NULL,
  `cntct` varchar(11) NOT NULL,
  `cntct_1` varchar(15) NOT NULL,
  `cntct_2` varchar(15) NOT NULL,
  `profile` varchar(10) NOT NULL,
  `view_profile` varchar(20) NOT NULL,
  `chng_pass` varchar(20) NOT NULL,
  `logout` varchar(10) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu_name`
--

INSERT INTO `menu_name` (`home`, `spr`, `at_report`, `fee_detail`, `cntct`, `cntct_1`, `cntct_2`, `profile`, `view_profile`, `chng_pass`, `logout`, `id`) VALUES
('Home', 'SPR', 'Attendence Report', 'Fee', 'Contact Us', '', '', 'Profile', 'View Profile', 'Change Password', 'Logout', 1);

-- --------------------------------------------------------

--
-- Table structure for table `NEET_2`
--

CREATE TABLE IF NOT EXISTS `NEET_2` (
  `id` int(11) NOT NULL,
  `exam_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `roll` int(10) DEFAULT NULL,
  `phy.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chem.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bot.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zoo.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `%` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rank` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test` int(9) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `NEET_3`
--

CREATE TABLE IF NOT EXISTS `NEET_3` (
  `id` int(11) NOT NULL,
  `exam_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `roll` int(10) DEFAULT NULL,
  `phy.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chem.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bot.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zoo.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `%` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rank` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test` int(9) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `NEET_4`
--

CREATE TABLE IF NOT EXISTS `NEET_4` (
  `id` int(11) NOT NULL,
  `exam_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `roll` int(10) DEFAULT NULL,
  `phy.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chem.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bot.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zoo.` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `%` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rank` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test` int(9) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nov`
--

CREATE TABLE IF NOT EXISTS `nov` (
  `id` int(11) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `roll` int(11) DEFAULT NULL,
  `s1` enum('p','a','h') DEFAULT NULL,
  `s2` enum('p','a','h') DEFAULT NULL,
  `s3` enum('p','a','h') DEFAULT NULL,
  `s4` enum('p','a','h') DEFAULT NULL,
  `s5` enum('p','a','h') DEFAULT NULL,
  `s6` enum('p','a','h') DEFAULT NULL,
  `s7` enum('p','a','h') DEFAULT NULL,
  `s8` enum('p','a','h') DEFAULT NULL,
  `s9` enum('p','a','h') DEFAULT NULL,
  `s10` enum('p','a','h') DEFAULT NULL,
  `s11` enum('p','a','h') DEFAULT NULL,
  `s12` enum('p','a','h') DEFAULT NULL,
  `s13` enum('p','a','h') DEFAULT NULL,
  `s14` enum('p','a','h') DEFAULT NULL,
  `s15` enum('p','a','h') DEFAULT NULL,
  `s16` enum('p','a','h') DEFAULT NULL,
  `s17` enum('p','a','h') DEFAULT NULL,
  `s18` enum('p','a','h') DEFAULT NULL,
  `s19` enum('p','a','h') DEFAULT NULL,
  `s20` enum('p','a','h') DEFAULT NULL,
  `s21` enum('p','a','h') DEFAULT NULL,
  `s22` enum('p','a','h') DEFAULT NULL,
  `s23` enum('p','a','h') DEFAULT NULL,
  `s24` enum('p','a','h') DEFAULT NULL,
  `s25` enum('p','a','h') DEFAULT NULL,
  `s26` enum('p','a','h') DEFAULT NULL,
  `s27` enum('p','a','h') DEFAULT NULL,
  `s28` enum('p','a','h') DEFAULT NULL,
  `s29` enum('p','a','h') DEFAULT NULL,
  `s30` enum('p','a','h') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `oct`
--

CREATE TABLE IF NOT EXISTS `oct` (
  `id` int(11) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `roll` int(11) DEFAULT NULL,
  `s1` enum('p','a','h') DEFAULT NULL,
  `s2` enum('p','a','h') DEFAULT NULL,
  `s3` enum('p','a','h') DEFAULT NULL,
  `s4` enum('p','a','h') DEFAULT NULL,
  `s5` enum('p','a','h') DEFAULT NULL,
  `s6` enum('p','a','h') DEFAULT NULL,
  `s7` enum('p','a','h') DEFAULT NULL,
  `s8` enum('p','a','h') DEFAULT NULL,
  `s9` enum('p','a','h') DEFAULT NULL,
  `s10` enum('p','a','h') DEFAULT NULL,
  `s11` enum('p','a','h') DEFAULT NULL,
  `s12` enum('p','a','h') DEFAULT NULL,
  `s13` enum('p','a','h') DEFAULT NULL,
  `s14` enum('p','a','h') DEFAULT NULL,
  `s15` enum('p','a','h') DEFAULT NULL,
  `s16` enum('p','a','h') DEFAULT NULL,
  `s17` enum('p','a','h') DEFAULT NULL,
  `s18` enum('p','a','h') DEFAULT NULL,
  `s19` enum('p','a','h') DEFAULT NULL,
  `s20` enum('p','a','h') DEFAULT NULL,
  `s21` enum('p','a','h') DEFAULT NULL,
  `s22` enum('p','a','h') DEFAULT NULL,
  `s23` enum('p','a','h') DEFAULT NULL,
  `s24` enum('p','a','h') DEFAULT NULL,
  `s25` enum('p','a','h') DEFAULT NULL,
  `s26` enum('p','a','h') DEFAULT NULL,
  `s27` enum('p','a','h') DEFAULT NULL,
  `s28` enum('p','a','h') DEFAULT NULL,
  `s29` enum('p','a','h') DEFAULT NULL,
  `s30` enum('p','a','h') DEFAULT NULL,
  `s31` enum('p','a','h') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `patteren`
--

CREATE TABLE IF NOT EXISTS `patteren` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `tname` varchar(50) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patteren`
--

INSERT INTO `patteren` (`id`, `name`, `class_id`, `tname`) VALUES
(2, 'NEET', 2, 'NEET_2'),
(3, 'AIIMS', 2, 'AIIMS_2'),
(4, 'NEET', 3, 'NEET_3'),
(5, 'AIIMS', 3, 'AIIMS_3'),
(6, 'BOARD', 3, 'BOARD_3'),
(7, 'NEET', 4, 'NEET_4'),
(8, 'BOARD', 4, 'BOARD_4'),
(9, 'AIIMS', 4, 'AIIMS_4'),
(10, 'MAINS', 9, 'MAINS_9'),
(11, 'ADVANCED', 9, 'ADVANCED_9'),
(12, 'MAINS', 10, 'MAINS_10'),
(13, 'BOARD', 10, 'BOARD_10'),
(14, 'ADVANCED', 10, 'ADVANCED_10'),
(15, 'MAINS', 11, 'MAINS_11'),
(16, 'BOARD', 11, 'BOARD_11'),
(17, 'ADVANCED', 11, 'ADVANCED_11');

-- --------------------------------------------------------

--
-- Table structure for table `profileexcel`
--

CREATE TABLE IF NOT EXISTS `profileexcel` (
  `id` int(11) NOT NULL,
  `filename` text NOT NULL,
  `datee` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sept`
--

CREATE TABLE IF NOT EXISTS `sept` (
  `id` int(11) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `roll` int(11) DEFAULT NULL,
  `s1` enum('p','a','h') DEFAULT NULL,
  `s2` enum('p','a','h') DEFAULT NULL,
  `s3` enum('p','a','h') DEFAULT NULL,
  `s4` enum('p','a','h') DEFAULT NULL,
  `s5` enum('p','a','h') DEFAULT NULL,
  `s6` enum('p','a','h') DEFAULT NULL,
  `s7` enum('p','a','h') DEFAULT NULL,
  `s8` enum('p','a','h') DEFAULT NULL,
  `s9` enum('p','a','h') DEFAULT NULL,
  `s10` enum('p','a','h') DEFAULT NULL,
  `s11` enum('p','a','h') DEFAULT NULL,
  `s12` enum('p','a','h') DEFAULT NULL,
  `s13` enum('p','a','h') DEFAULT NULL,
  `s14` enum('p','a','h') DEFAULT NULL,
  `s15` enum('p','a','h') DEFAULT NULL,
  `s16` enum('p','a','h') DEFAULT NULL,
  `s17` enum('p','a','h') DEFAULT NULL,
  `s18` enum('p','a','h') DEFAULT NULL,
  `s19` enum('p','a','h') DEFAULT NULL,
  `s20` enum('p','a','h') DEFAULT NULL,
  `s21` enum('p','a','h') DEFAULT NULL,
  `s22` enum('p','a','h') DEFAULT NULL,
  `s23` enum('p','a','h') DEFAULT NULL,
  `s24` enum('p','a','h') DEFAULT NULL,
  `s25` enum('p','a','h') DEFAULT NULL,
  `s26` enum('p','a','h') DEFAULT NULL,
  `s27` enum('p','a','h') DEFAULT NULL,
  `s28` enum('p','a','h') DEFAULT NULL,
  `s29` enum('p','a','h') DEFAULT NULL,
  `s30` enum('p','a','h') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_biodata`
--

CREATE TABLE IF NOT EXISTS `student_biodata` (
  `id` int(20) NOT NULL,
  `pswd` text NOT NULL,
  `roll` varchar(5) NOT NULL,
  `s_name` varchar(50) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `m_name` varchar(50) NOT NULL,
  `class` varchar(12) NOT NULL,
  `batch` varchar(5) NOT NULL,
  `email` varchar(70) NOT NULL,
  `f_mobile` varchar(11) NOT NULL,
  `m_mobile` varchar(11) NOT NULL,
  `s_mobile` varchar(11) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `cat` enum('GEN','OBC','SC','ST') NOT NULL,
  `dob` varchar(10) NOT NULL,
  `ll_no` varchar(11) NOT NULL,
  `adrs` varchar(500) NOT NULL,
  `state` varchar(30) NOT NULL DEFAULT 'Rajasthan',
  `district` varchar(25) NOT NULL,
  `pin` varchar(6) NOT NULL,
  `propic` text NOT NULL,
  `10th_roll` varchar(20) NOT NULL,
  `10th_%` varchar(20) NOT NULL,
  `10th_school_name` varchar(20) NOT NULL,
  `10th_board` varchar(20) NOT NULL,
  `12th_roll` varchar(20) NOT NULL,
  `12th_%` varchar(20) NOT NULL,
  `12th_school_name` varchar(20) NOT NULL,
  `12th_board` varchar(20) NOT NULL,
  `aipmt_roll` varchar(20) NOT NULL,
  `aiims_roll` varchar(20) NOT NULL,
  `aipvt_roll` varchar(20) NOT NULL,
  `iit_roll` varchar(20) NOT NULL,
  `remark` text NOT NULL,
  `fee_disc` varchar(4) NOT NULL,
  `doa` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_biodata`
--

INSERT INTO `student_biodata` (`id`, `pswd`, `roll`, `s_name`, `f_name`, `m_name`, `class`, `batch`, `email`, `f_mobile`, `m_mobile`, `s_mobile`, `gender`, `cat`, `dob`, `ll_no`, `adrs`, `state`, `district`, `pin`, `propic`, `10th_roll`, `10th_%`, `10th_school_name`, `10th_board`, `12th_roll`, `12th_%`, `12th_school_name`, `12th_board`, `aipmt_roll`, `aiims_roll`, `aipvt_roll`, `iit_roll`, `remark`, `fee_disc`, `doa`) VALUES
(1, '9201cba3a056ca2df31f350799e4eca2', '12345', 'Vivek Modi', 'Manohar Lal Modi', 'Seema Modi', '2', '3', 'modiv2301@gmail.com', '9251737789', '', '9024555623', 'male', 'GEN', '23-01-1994', '1512234376', 'bikaner', 'rajasthan', 'bikaner', '334001', '1499926110_Koala.jpg', '5646434564', '85', 'R.S.V. Sr. sec. scho', 'CBSE', '56546', '88', 'adarsh high school', 'RBSE', '', '', '', '', '', '0', '13/7/2017'),
(2, '165a8c8b977ff6a5f957bfd301d12ba0', '12346', 'ramnaresh ', 'ramesh', 'menna', '2', '6', 'ramu@gmail.com', '7857465245', '', '7665666933', 'male', 'GEN', '25-08-1994', '1512244662', 'bikaner', 'rajasthan', 'bikaner', '334003', '', '56545656', '60', 'R.S.V. Sr. sec. scho', 'RBSE', '6565', '62', 'adarsh high school', 'RBSE', '', '', '', '', '', '', '15/7/2017');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ADVANCED_9`
--
ALTER TABLE `ADVANCED_9`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ADVANCED_10`
--
ALTER TABLE `ADVANCED_10`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ADVANCED_11`
--
ALTER TABLE `ADVANCED_11`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `AIIMS_2`
--
ALTER TABLE `AIIMS_2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `AIIMS_3`
--
ALTER TABLE `AIIMS_3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `AIIMS_4`
--
ALTER TABLE `AIIMS_4`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ap`
--
ALTER TABLE `ap`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aug`
--
ALTER TABLE `aug`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `batch`
--
ALTER TABLE `batch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `BOARD_3`
--
ALTER TABLE `BOARD_3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `BOARD_4`
--
ALTER TABLE `BOARD_4`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `BOARD_10`
--
ALTER TABLE `BOARD_10`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `BOARD_11`
--
ALTER TABLE `BOARD_11`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coloumn`
--
ALTER TABLE `coloumn`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `decm`
--
ALTER TABLE `decm`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feb`
--
ALTER TABLE `feb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feesexcel`
--
ALTER TABLE `feesexcel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fees_submit`
--
ALTER TABLE `fees_submit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `general_setting`
--
ALTER TABLE `general_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jan`
--
ALTER TABLE `jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `july`
--
ALTER TABLE `july`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `june`
--
ALTER TABLE `june`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_admin`
--
ALTER TABLE `login_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `MAINS_9`
--
ALTER TABLE `MAINS_9`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `MAINS_10`
--
ALTER TABLE `MAINS_10`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `MAINS_11`
--
ALTER TABLE `MAINS_11`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `march`
--
ALTER TABLE `march`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `may`
--
ALTER TABLE `may`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_name`
--
ALTER TABLE `menu_name`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `NEET_2`
--
ALTER TABLE `NEET_2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `NEET_3`
--
ALTER TABLE `NEET_3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `NEET_4`
--
ALTER TABLE `NEET_4`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nov`
--
ALTER TABLE `nov`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oct`
--
ALTER TABLE `oct`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patteren`
--
ALTER TABLE `patteren`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profileexcel`
--
ALTER TABLE `profileexcel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sept`
--
ALTER TABLE `sept`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_biodata`
--
ALTER TABLE `student_biodata`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ADVANCED_9`
--
ALTER TABLE `ADVANCED_9`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ADVANCED_10`
--
ALTER TABLE `ADVANCED_10`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ADVANCED_11`
--
ALTER TABLE `ADVANCED_11`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `AIIMS_2`
--
ALTER TABLE `AIIMS_2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `AIIMS_3`
--
ALTER TABLE `AIIMS_3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `AIIMS_4`
--
ALTER TABLE `AIIMS_4`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ap`
--
ALTER TABLE `ap`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `aug`
--
ALTER TABLE `aug`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `batch`
--
ALTER TABLE `batch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `BOARD_3`
--
ALTER TABLE `BOARD_3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `BOARD_4`
--
ALTER TABLE `BOARD_4`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `BOARD_10`
--
ALTER TABLE `BOARD_10`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `BOARD_11`
--
ALTER TABLE `BOARD_11`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `coloumn`
--
ALTER TABLE `coloumn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=106;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `decm`
--
ALTER TABLE `decm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `feb`
--
ALTER TABLE `feb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `feesexcel`
--
ALTER TABLE `feesexcel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `fees_submit`
--
ALTER TABLE `fees_submit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `general_setting`
--
ALTER TABLE `general_setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `jan`
--
ALTER TABLE `jan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `july`
--
ALTER TABLE `july`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `june`
--
ALTER TABLE `june`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `login_admin`
--
ALTER TABLE `login_admin`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `MAINS_9`
--
ALTER TABLE `MAINS_9`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `MAINS_10`
--
ALTER TABLE `MAINS_10`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `MAINS_11`
--
ALTER TABLE `MAINS_11`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `march`
--
ALTER TABLE `march`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `may`
--
ALTER TABLE `may`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `menu_name`
--
ALTER TABLE `menu_name`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `NEET_2`
--
ALTER TABLE `NEET_2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `NEET_3`
--
ALTER TABLE `NEET_3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `NEET_4`
--
ALTER TABLE `NEET_4`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `nov`
--
ALTER TABLE `nov`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oct`
--
ALTER TABLE `oct`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `patteren`
--
ALTER TABLE `patteren`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `profileexcel`
--
ALTER TABLE `profileexcel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `sept`
--
ALTER TABLE `sept`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `student_biodata`
--
ALTER TABLE `student_biodata`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
